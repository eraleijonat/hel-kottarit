import{default as t}from"../components/pages/johtajille/_page.svelte-e131a770.js";const e=!0;export{t as component,e as has_server_load};
