import{default as t}from"../components/error.svelte-f179dcdf.js";export{t as component};
