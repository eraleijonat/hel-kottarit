import{default as t}from"../components/pages/_layout.svelte-32632e79.js";const e=!0;export{t as component,e as has_server_load};
