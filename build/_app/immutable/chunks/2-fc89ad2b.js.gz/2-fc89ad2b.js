import{default as t}from"../components/pages/_page.svelte-d65a2f41.js";const e=!0;export{t as component,e as has_server_load};
