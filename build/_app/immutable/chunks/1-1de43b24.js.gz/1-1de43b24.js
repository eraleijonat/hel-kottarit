import{default as t}from"../components/error.svelte-77c97646.js";export{t as component};
