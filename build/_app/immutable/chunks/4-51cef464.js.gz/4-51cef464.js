import{default as t}from"../components/pages/lippukunta/_page.svelte-e9d7954d.js";const e=!0;export{t as component,e as has_server_load};
